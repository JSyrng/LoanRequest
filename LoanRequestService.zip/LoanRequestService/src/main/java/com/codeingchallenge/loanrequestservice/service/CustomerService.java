package com.codeingchallenge.loanrequestservice.service;

import com.codeingchallenge.loanrequestservice.model.Customer;
import com.codeingchallenge.loanrequestservice.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class CustomerService {

    CustomerRepository customerRepository;
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public BigDecimal getTotalLoanAmountByCustomerId(Long customerId) {
        Optional<Customer> customerOptional = customerRepository.findById(customerId);

        if (customerOptional.isPresent()) {
            Customer customer = customerOptional.get();
            return customer.getTotalLoanAmount();
        }
        throw new IllegalArgumentException("Customer with ID " + customerId + " not found.");
    }

    public void saveCustomer(Customer customer) {
        customerRepository.save(customer);
    }



}
