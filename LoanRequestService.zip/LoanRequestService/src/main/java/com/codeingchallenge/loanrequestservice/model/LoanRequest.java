package com.codeingchallenge.loanrequestservice.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@Entity
public class LoanRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @DecimalMin(value = "500.00", message = "Loan amount must be at least 500")
    @DecimalMax(value = "12000.50", message = "Loan amount cannot exceed 12000.50")
    private BigDecimal amount;

    @NotNull
    private String customerFullName;

    @NotNull
    private Long customerId;
}
