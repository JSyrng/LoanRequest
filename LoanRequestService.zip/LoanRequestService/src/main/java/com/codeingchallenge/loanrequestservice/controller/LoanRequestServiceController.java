package com.codeingchallenge.loanrequestservice.controller;

import com.codeingchallenge.loanrequestservice.model.LoanRequest;
import com.codeingchallenge.loanrequestservice.service.CustomerService;
import com.codeingchallenge.loanrequestservice.service.LoanRequestService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

@RestController
@RequestMapping("/loanrequest")
public class LoanRequestServiceController {

    private final LoanRequestService loanRequestService;
    private final CustomerService customerService;

    public LoanRequestServiceController(CustomerService customerService, LoanRequestService loanRequestService) {
        this.customerService = customerService;
        this.loanRequestService = loanRequestService;
    }

    @GetMapping("/sum/{id}")
    public ResponseEntity<BigDecimal> getSumOfLoans(@PathVariable("id") long id) {
        BigDecimal totalAmount = customerService.getTotalLoanAmountByCustomerId(id);
        if (totalAmount == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(BigDecimal.ZERO); // Return 404 if customer is not found.
        }
        return ResponseEntity.ok(totalAmount);
    }

    @PostMapping("/create")
    public ResponseEntity<String> create(@Valid @RequestBody LoanRequest loanRequest) {
        loanRequestService.createLoanRequest(loanRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body("Loan request created successfully.");
    }
}
