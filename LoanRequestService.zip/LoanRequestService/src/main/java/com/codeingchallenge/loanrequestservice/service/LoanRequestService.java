package com.codeingchallenge.loanrequestservice.service;

import com.codeingchallenge.loanrequestservice.model.Customer;
import com.codeingchallenge.loanrequestservice.model.LoanRequest;
import com.codeingchallenge.loanrequestservice.repository.CustomerRepository;
import com.codeingchallenge.loanrequestservice.repository.LoanRequestRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Optional;

@Service
public class LoanRequestService {

    private final LoanRequestRepository loanRequestRepository;
    private final CustomerRepository customerRepository;

    public LoanRequestService(LoanRequestRepository loanRequestRepository, CustomerRepository customerRepository) {
        this.loanRequestRepository = loanRequestRepository;
        this.customerRepository = customerRepository;
    }

    @Transactional
    public void createLoanRequest(LoanRequest loanRequest) {
        Optional<Customer> customerOptional = customerRepository.findById(loanRequest.getCustomerId());

        if (customerOptional.isEmpty()) {
            throw new IllegalArgumentException("Customer with ID " + loanRequest.getCustomerId() + " not found.");
        }

        Customer customer = customerOptional.get();

        if (!customer.getFullName().equals(loanRequest.getCustomerFullName())) {
            throw new IllegalArgumentException("Customer name does not match with the ID provided.");
        }

        LoanRequest savedLoan = loanRequestRepository.save(loanRequest);

        BigDecimal newTotal = customer.getTotalLoanAmount().add(savedLoan.getAmount());
        customer.setTotalLoanAmount(newTotal);

        customerRepository.save(customer);
    }
}
