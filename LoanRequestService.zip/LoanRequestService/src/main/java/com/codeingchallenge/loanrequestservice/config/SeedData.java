package com.codeingchallenge.loanrequestservice.config;

import com.codeingchallenge.loanrequestservice.model.Customer;
import com.codeingchallenge.loanrequestservice.model.LoanRequest;
import com.codeingchallenge.loanrequestservice.service.CustomerService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
public class SeedData implements CommandLineRunner {

    CustomerService customerService;
    public SeedData(CustomerService customerService) {
        this.customerService = customerService;
    }

    @Override
    public void run(String... args) throws Exception {
        Customer customer1 = new Customer();
        customer1.setId(1L);
        customer1.setFullName("Mike");
        customer1.setTotalLoanAmount(new BigDecimal(0));

        Customer customer2 = new Customer();
        customer2.setId(2L);
        customer2.setFullName("Eva");
        customer2.setTotalLoanAmount(new BigDecimal(0));

        Customer customer3 = new Customer();
        customer3.setId(3L);
        customer3.setFullName("Ivo");
        customer3.setTotalLoanAmount(new BigDecimal(0));

        Customer customer4 = new Customer();
        customer4.setId(4L);
        customer4.setFullName("Max");
        customer4.setTotalLoanAmount(new BigDecimal(0));


        customerService.saveCustomer(customer1);
        customerService.saveCustomer(customer2);
        customerService.saveCustomer(customer3);
        customerService.saveCustomer(customer4);

    }

}
