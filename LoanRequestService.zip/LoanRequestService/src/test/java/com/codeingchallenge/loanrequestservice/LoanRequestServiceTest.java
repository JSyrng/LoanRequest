package com.codeingchallenge.loanrequestservice;

import com.codeingchallenge.loanrequestservice.model.Customer;
import com.codeingchallenge.loanrequestservice.model.LoanRequest;
import com.codeingchallenge.loanrequestservice.repository.CustomerRepository;
import com.codeingchallenge.loanrequestservice.repository.LoanRequestRepository;
import com.codeingchallenge.loanrequestservice.service.LoanRequestService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class LoanRequestServiceTest {

    @Mock
    private LoanRequestRepository loanRequestRepository;

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private LoanRequestService loanRequestService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateLoanRequest_Success() {

        Customer customer = new Customer();
        customer.setId(1L);
        customer.setFullName("John Doe");
        customer.setTotalLoanAmount(BigDecimal.valueOf(1000));

        LoanRequest loanRequest = new LoanRequest();
        loanRequest.setCustomerId(1L);
        loanRequest.setCustomerFullName("John Doe");
        loanRequest.setAmount(BigDecimal.valueOf(500));

        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));
        when(loanRequestRepository.save(any(LoanRequest.class))).thenReturn(loanRequest);

        loanRequestService.createLoanRequest(loanRequest);

        verify(customerRepository, times(1)).save(customer);
        verify(loanRequestRepository, times(1)).save(loanRequest);
    }

    @Test
    void testCreateLoanRequest_CustomerNotFound() {

        LoanRequest loanRequest = new LoanRequest();
        loanRequest.setCustomerId(1L);
        loanRequest.setCustomerFullName("John Doe");

        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> loanRequestService.createLoanRequest(loanRequest));
    }

    @Test
    void testCreateLoanRequest_NameMismatch() {
        // Arrange
        Customer customer = new Customer();
        customer.setId(1L);
        customer.setFullName("John Smith");

        LoanRequest loanRequest = new LoanRequest();
        loanRequest.setCustomerId(1L);
        loanRequest.setCustomerFullName("John Doe");

        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));

        assertThrows(IllegalArgumentException.class, () -> loanRequestService.createLoanRequest(loanRequest));
    }
}
