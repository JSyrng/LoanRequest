package com.codeingchallenge.loanrequestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanRequestServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
