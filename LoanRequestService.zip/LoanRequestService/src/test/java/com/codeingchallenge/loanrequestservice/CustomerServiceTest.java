package com.codeingchallenge.loanrequestservice;

import com.codeingchallenge.loanrequestservice.model.Customer;
import com.codeingchallenge.loanrequestservice.repository.CustomerRepository;
import com.codeingchallenge.loanrequestservice.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class CustomerServiceTest {

    @Mock
    private CustomerRepository customerRepository;

    @InjectMocks
    private CustomerService customerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetTotalLoanAmountByCustomerId_Success() {
        // Arrange
        Customer customer = new Customer();
        customer.setId(1L);
        customer.setFullName("John Doe");
        customer.setTotalLoanAmount(BigDecimal.valueOf(1500));

        when(customerRepository.findById(1L)).thenReturn(Optional.of(customer));

        BigDecimal totalAmount = customerService.getTotalLoanAmountByCustomerId(1L);

        assertEquals(BigDecimal.valueOf(1500), totalAmount);
    }

    @Test
    void testGetTotalLoanAmountByCustomerId_CustomerNotFound() {

        when(customerRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class, () -> customerService.getTotalLoanAmountByCustomerId(1L));
    }

    @Test
    void testSaveCustomer() {

        Customer customer = new Customer();
        customer.setId(1L);
        customer.setFullName("John Doe");

        // Act
        customerService.saveCustomer(customer);

        verify(customerRepository, times(1)).save(customer);
    }
}
