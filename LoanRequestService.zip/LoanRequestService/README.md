
# Loan Request Service

Dies ist ein Java Spring Boot Projekt, das einen **Loan Request Service** bereitstellt. Der Service ermöglicht das Erstellen von Kreditanfragen und das Abrufen der Gesamtsumme aller Kreditanfragen eines Kunden.

## Seed Daten

Das Projekt wird mit einigen vordefinierten Seed-Daten initialisiert. Diese Daten sind nach dem Start des Projekts unter `http://localhost:8080` verfügbar.

- Kunde 1:
    - Name: Max
    - Kundennummer: 1

- Kunde 2:
    - Name: Eva
    - Kundennummer: 2
  
- Kunde 3:
    - Name: Ivo
    - Kundennummer: 3

- Kunde 4:
    - Name: Max
    - Kundennummer: 4

## API-Schnittstellen

### 1. Kreditanfrage erstellen
- **URL**: `POST /loanrequest/create`
- **Beschreibung**: Erstellt eine neue Kreditanfrage für einen Kunden.
- **Request Body**:
   ```json
   {
      "amount": 678,
      "customerFullName": "Eva",
      "customerId": 2   
   }
   ```
- **Erfolgreiche Antwort**: Status 201 (Created) und Nachricht "Loan request created successfully."

### 2. Gesamtsumme der Kreditanfragen eines Kunden abrufen
- **URL**: `GET /loanrequest/sum/{customerId}`
- **Beschreibung**: Gibt die Gesamtsumme aller Kreditanfragen eines Kunden zurück.
- **Beispiel**:
   ```bash
   GET http://localhost:8080/loanrequest/sum/2
   ```
- **Erfolgreiche Antwort**: Status 200 und die Gesamtsumme der Kreditanfragen im JSON-Format:
   ```json
   {
      "totalLoanAmount": 678.00
   }
   ```

## Fehlermeldungen

1. **Kunde nicht gefunden**:
    - Wenn die Kundennummer ungültig ist oder nicht existiert, wird eine 404-Fehlerantwort mit der Nachricht "Customer with ID {customerId} not found." zurückgegeben.

2. **Validierungsfehler**:
    - Wenn die Kreditanfrage nicht den festgelegten Validierungsregeln entspricht (z.B. Kreditbetrag außerhalb des zulässigen Bereichs), wird ein 400-Fehler mit der jeweiligen Fehlermeldung zurückgegeben.
